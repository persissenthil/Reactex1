import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';

class App extends Component {
  render() {
    return (
      <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
          <p>
            Edit <code>src/App.js</code> and save to reload.
          </p>
		  <p className="App-intro">
		  Hello Codecademy!
		  </p>
		  <h1>Welcome to Nebanking</h1>
		  <table>
		  <tr>
		  <td><label for="username">your user name:</label></td>
		  <td><input name="username" size="35" maxlength="50" type="text"/></td>
		  </tr>
		  <tr>
		  <td><label for="pwd">your password:</label></td>
		  <td><input name="pwd" size="35" maxlength="50" type="password"/></td>

		  </tr>
		  <tr><td>&nbsp;</td>
		  <td><input name="Submit" size="35" maxlength="50" type="submit" value="Submit"/></td>
           </tr>
		  </table>
          <a
            className="App-link"
            href="https://reactjs.org"
            target="_blank"
            rel="noopener noreferrer"
          >
            Learn React
          </a>
        </header>
      </div>
    );
  }
}

export default App;
